package cat.proven.main;


import cat.proven.store.controllers.MainController;
import cat.proven.store.model.Model;
import cat.proven.store.model.persist.DbConnect;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * MVC Main class for Store Application.
 * @author ProvenSoft
 */
public class MainMVC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainMVC app= new MainMVC();
        app.run();
    }

    private void run() {
        
        try {
            DbConnect.loadDriver();
            Model model = new Model();
            MainController controller = new MainController(model);
            controller.start();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MainMVC.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
