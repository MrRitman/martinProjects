package cat.proven.store.model.persist;

import cat.proven.store.model.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ProvenSoft
 */
public class ProductDao {
    
    private final String QUERY_SELECT_WHERE_CODE = "select * from products";
    private Product p;
    private ResultSet rs;

    public ProductDao() {
        resultSetConnection();
    }
    
    
    
    
    private void resultSetConnection(){
        
        Connection connection;
        
        try {
            
            connection = DbConnect.getConnection();
            Statement stmt = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            rs = stmt.executeQuery(QUERY_SELECT_WHERE_CODE);
            
            
            
        } catch (SQLException ex) {
            connection = null;
        }
        
        
        
    }
    
    
    
    /**
     * Get the database info (result set) and transform into a product
     * @param rs the info from data source
     * @return a product
     * @throws SQLException 
     */
    private Product resultSetToProduct(ResultSet result) throws SQLException{
        
        String code = result.getString("code");
        String description = result.getString("description");
        double price = result.getDouble("price");
        int stock = result.getInt("stock");
        
        p = new Product(code, description, price, stock);
        
        
        return p;
        
    }
    
    /**
     * Calls ResultSet next method
     * @return the next product from current position in data source
     * @throws SQLException 
     */
    public Product nextResultSet() throws SQLException{
        
        rs.next();
        
        p = resultSetToProduct(rs);
        
        return p;
        
    }
    
    /**
     * Calls ResultSet first method
     * @return the first product in data source
     * @throws SQLException 
     */
    public Product firstResultSet() throws SQLException{
        
        rs.first();
        
        p = resultSetToProduct(rs);
        
        return p;
        
    }
    
    /**
     * Calls ResultSet last method
     * @return the last product in data source
     * @throws SQLException 
     */
    public Product lastResultSet() throws SQLException{
        
        rs.last();
        
        p = resultSetToProduct(rs);
        
        return p;
        
    }
    
    /**
     * Calls ResultSet previous method
     * @return the previous product from current position in data source
     * @throws SQLException 
     */
    public Product previousResultSet() throws SQLException{
        
        rs.previous();
        
        p = resultSetToProduct(rs);
        
        return p;
        
    }
    
    /**
     * Inserts a product in data source
     * @param product to create
     * @return true in case of created, false if not
     */
    public boolean insertProduct(Product product){
        
        boolean isCreated = false;
        
        
        try {
            rs.moveToInsertRow();
            rs.updateString("code", product.getCode());
            rs.updateString("description", product.getDescription());
            rs.updateDouble("price", product.getPrice());
            rs.updateInt("stock", product.getStock());
            
            rs.insertRow();
            rs.moveToCurrentRow();
            
            isCreated = true;
            
        } catch (SQLException ex) {
            isCreated = false;
        } 
        
        return isCreated;
    }
    
    /**
     * Modifies the selected item, updating it's data into data source
     * @param product the product to update
     * @return true in case of being modified, false if not
     */
    public boolean modifyProduct(Product product){
        
        boolean isModified;

            try {

                rs.updateString("code", product.getCode());
                rs.updateString("description", product.getDescription());
                rs.updateDouble("price", product.getPrice());
                rs.updateInt("stock", product.getStock());

                rs.updateRow();
                isModified = true;

            } catch (SQLException ex) {
                isModified = false;
            } 

        
        
        
        return isModified;
        
    }
    
    public boolean deleteProduct(Product product){
        
        boolean isRemoved;
        
        try {
            rs.deleteRow();
            isRemoved = true;
            
        } catch (SQLException ex) {
            isRemoved = false;
        }
        
        
        
        
        
        return isRemoved;
    }
    
    
    
    
    
}
