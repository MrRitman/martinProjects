package cat.proven.store.model;


import cat.proven.store.model.persist.ProductDao;
import java.sql.SQLException;

/**
 *
 * @author ProvenSoft
 */
public class Model {
    
    private final ProductDao productDao;
    private Product p;
    

    //contructor
    public Model() {
        //instance of DAO to access DATA
        productDao = new ProductDao();
    }
    
    /**
     * Calls firstResultSet method from productDAO class
     * @return a product
     */
    public Product first(){
        try {
            p = productDao.firstResultSet();
        } catch (SQLException ex) {
            
        }
        
        return p;
    }
    
    /**
     * Calls nextResultSet method from productDAO class
     * @return a product
     */
    public Product next(){
        
        try {
            p = productDao.nextResultSet();
        } catch (SQLException ex) {
            
        }
        
        return p;
        
    }
    
    /**
     * Calls previousResultSet method from productDAO class
     * @return a product
     */
    public Product previous(){
        
        try {
            p = productDao.previousResultSet();
        } catch (SQLException ex) {
            
        }
        
        return p;
        
    }
    
    /**
     * Calls lastResultSet method from productDAO class
     * @return a product
     */
    public Product last(){
        
        try {
            p = productDao.lastResultSet();
            
        } catch (SQLException ex) {
            
        }
        
        return p;
    }
    
    public boolean insert(Product product){
        
        boolean isCreated;
        
        isCreated = productDao.insertProduct(product);
        
        return isCreated;
    }
    
    public boolean update(Product product){
        
        boolean isModified;
        
        isModified = productDao.modifyProduct(product);
        
        return isModified;
        
        
    }
    
    public boolean remove(Product product){
        
        boolean isRemoved;
        
        isRemoved = productDao.deleteProduct(product);
        
        return isRemoved;
        
    }

}
