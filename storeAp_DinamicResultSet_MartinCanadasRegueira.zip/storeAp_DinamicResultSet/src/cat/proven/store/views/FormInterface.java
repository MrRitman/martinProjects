/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.store.views;

import cat.proven.store.model.Product;

/**
 *
 * @author ProvenSoft
 */
public interface FormInterface {
    /**
     * read product data from user.
     * @return product or null in case of error.
     */
    
    
    
    Product input();
    
    
}
