package cat.proven.store.views;

import cat.proven.menu.Menu;
import cat.proven.menu.MenuItem;

/**
 *
 * @author ProvenSoft
 */
public class MainMenu extends Menu {
    
    public MainMenu(){
        setTitle("*****Store Main Menu*****");
        addOption( new MenuItem("Quit","quit"));
        addOption( new MenuItem("First", "first"));
        addOption( new MenuItem("Next", "next"));
        addOption( new MenuItem("Previous", "previous"));
        addOption( new MenuItem("Last", "last"));
        addOption( new MenuItem("Update", "update"));
        addOption( new MenuItem("Insert", "insert"));
        addOption( new MenuItem("Delete", "delete"));
        
        
                       
    }
    
   
    
}
