/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.store.views;

import cat.proven.store.model.Product;
import cat.proven.util.InOut;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author ProvenSoft
 */
public class ProductForm implements FormInterface{
    
    private final Scanner sc = InOut.getScanner();

    @Override
    public Product input() {
        
        Product p = null;

        System.out.println("code: ");
        String code = sc.next();
        System.out.println("description: ");
        String description = sc.next();

        try {
            System.out.println("price: ");
            double price = sc.nextDouble();
            System.out.println("stock: ");
            int stock = sc.nextInt();

            if (price < 0 || stock < 0) {
                System.out.println("The code and/or the stock can't be inferior to 0.");
            } else {
                p = new Product(code, description, price, stock);
            }

        } catch (InputMismatchException e) {
            System.out.println("Please, input only numerical values.");
            p = null;
            sc.next();
        }

        return p;

    }


    
    
}
