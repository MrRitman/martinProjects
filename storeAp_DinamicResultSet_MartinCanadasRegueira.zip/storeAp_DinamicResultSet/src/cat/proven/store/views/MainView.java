package cat.proven.store.views;

import cat.proven.menu.Menu;
import cat.proven.store.controllers.MainController;
import cat.proven.store.model.Model;
import cat.proven.store.model.Product;
import cat.proven.util.InOut;
import java.util.Scanner;

/**
 * Main view of Store application.
 * @author ProvenSoft
 */
public class MainView {
    
    private final MainController controller;
    private final Model model;
    private final Menu menu;
    private final Scanner sc;
    
    private boolean exit;


    
    public MainView(MainController controller, Model model){
        this.controller = controller;
        this.model = model;
        this.menu = new MainMenu();
        this.sc = InOut.getScanner();
    }
    
    public boolean isExit() {
        return exit;
    }

    public void setExit(boolean exit) {
        this.exit = exit;
    }
    
    public void display(){
        
        exit = false;
        
        do{            
            
            menu.show();
            String action = menu.getSelectedOptionActionCommand();
            processAction(action);
            
        }while(!exit);
    }

    private void processAction(String action) {
        if(action != null){
            switch(action){
                default:
                    controller.processRequest(action);
            }
        }
    }
    
        /*********** VIEW METHODS ***********/

        
    /**
     * displays a message and reads an answer from the user.
     * @param message the message to display.
     * @return the answer from the user or null in case of error.
     */
    public String inputString(String message) {
        System.out.print(message);        
        Scanner sc = InOut.getScanner();
        return sc.next();
    }
    
    /**
     * displays a product to user.
     * @param product the product to display.
     */
    public void displayProduct(Product product) {
        if (product != null) {
            System.out.println(product.toString());
        } else {
            System.out.println("Null product!");
        }
    }

    /**
     * displays a message to user.
     * @param message to display
     */
    public void displayMessage(String message) {
        
        System.out.println(message);
        
    }

    public boolean confirm(String message) {
        
        boolean confirm = false;
        char confirmLetter;
        
        System.out.println(message); //Are you sure? (Y/N)?
        confirmLetter = sc.next().charAt(0);
        
        while(confirmLetter != 'Y' && confirmLetter != 'N'){
            System.out.println("Please, input only Y or N.");
            confirmLetter = sc.next().charAt(0);
        }
        
        if(confirmLetter == 'Y'){
            confirm = true;
        }
        
        return confirm;
        
        
    }
    
}
