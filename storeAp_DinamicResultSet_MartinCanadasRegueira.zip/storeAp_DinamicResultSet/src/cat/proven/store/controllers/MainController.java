package cat.proven.store.controllers;

import cat.proven.store.model.Model;
import cat.proven.store.model.Product;
import cat.proven.store.views.MainView;
import cat.proven.store.views.ProductForm;

/**
 * Main controller of Store application.
 * @author ProvenSoft
 */
public class MainController {

    private final Model model;
    private final MainView view;
    private final ProductForm pform;
    private Product p;

    public MainController(Model model) {
        this.model = model;
        this.view = new MainView(this, model);
        this.pform = new ProductForm();
    }
    
    public void start(){
        view.display();
    }

    public void processRequest(String action) {
            
            if(action==null){
                action = "wrongoption";
            }else{
                
                switch (action) {
                    case "quit": //exit
                        view.setExit(true);
                        view.displayMessage("Goodbye!");
                        break;
                    case "first": 
                        showFirst();
                        break;
                    case "next": 
                        showNext();
                        break;
                    case "previous": 
                        showPrevious();
                        break;
                    case "last":
                        showLast();
                        break;
                    case "update": 
                        updateData();
                        break;
                    case "insert": 
                        insertData();
                        break;
                    case "wrongoption": 
                        view.displayMessage("Wrong Option");
                        break;  
                    case "delete":
                        deleteData();
                        break;
                    default:
                        view.displayMessage("Invalid option!");
                    
            }

        }

        //System.out.println("Processing action: "+action);
    }

    /**
     * Shows first item
     */
    private void showFirst() {

        p = model.first();
        view.displayProduct(p);

    }

    /**
     * Shows next item from current position
     */
    private void showNext() {

        p = model.next();
        view.displayProduct(p);

    }

    /**
     * Shows previous item from current position
     */
    private void showPrevious() {

        p = model.previous();
        view.displayProduct(p);
    }

    /**
     * Shows last item
     */
    private void showLast() {

        p = model.last();
        view.displayProduct(p);

    }

    private void insertData() {

        boolean isCreated;

        Product product;

        product = pform.input();
        
        if(product != null){
            
            isCreated = model.insert(product);
            
        }else{
            isCreated = false;
        }

        

        if (isCreated) {
            view.displayMessage("Product created. ");
        } else {
            view.displayMessage("Product not created.");
        }


        
    }

    private void updateData() {

        boolean isModified;
        boolean confirmAction;

        Product product;

        if (p != null) {
            
            product = pform.input();
            
            view.displayProduct(p);
            view.displayMessage("New " +product);
            
            confirmAction = view.confirm("Are you sure you want to update this product? (Y/N)");
            
            
            if(confirmAction){
                isModified = model.update(product);
            }else{
                isModified = false;
            }
            

        } else {

            view.displayMessage("Please, select a product.");
            isModified = false;

        }

        if (isModified) {
            view.displayMessage("Product modified.");
        } else {
            view.displayMessage("Product not modified.");
        }

        
    }

    private void deleteData() {
        
        boolean isRemoved = false;
        boolean confirmAction;

        if (p != null) {

            view.displayMessage("Product to remove: ");
            view.displayProduct(p);

            confirmAction = view.confirm("Remove that product? (Y/N): ");

            if (confirmAction) {
                isRemoved = model.remove(p);
            }

            if (isRemoved) {
                view.displayMessage("Product removed.");
            } else {
                view.displayMessage("Product not removed.");
            }

        }else{
            view.displayMessage("Please, select a product.");
        }

        
        
        
    }
    
    

       
}    